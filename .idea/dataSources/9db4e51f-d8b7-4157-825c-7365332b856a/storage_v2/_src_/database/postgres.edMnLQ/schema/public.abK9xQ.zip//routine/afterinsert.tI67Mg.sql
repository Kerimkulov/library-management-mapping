create function afterinsert() returns trigger
as
$$
BEGIN
  INSERT INTO trigger_table(firstname,cust_id,date) VALUES(NEW.firstname,NEW.cust_id,current_date);

  RETURN NEW;
 END;
$$;

